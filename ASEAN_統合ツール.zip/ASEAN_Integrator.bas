Attribute VB_Name = "ASEAN_Integrator"
Option Explicit

' ASEAN model panel builder, v1.0, 2026-10-05.
' Windows desktop Excel. Late binding: no additional reference required.
' No network calls, no external workbook writes. Inputs are pasted into this workbook.
' All output sheets are refreshed snapshots; source/config/mapping sheets are preserved.
Private cfg As Object, rules As Object, families As Object, blocks As Object
Private series As Object, crosswalk As Object, origins As Object, audit As Object
Private summaries As Object, cohorts As Object, cohortSeen As Object, annualML As Object
Private months As Object, manualEvents As Object, logs As Collection, reviews As Collection
Private spData As Variant, spCols As Object, monthKeys As Variant
Private panelWs As Worksheet, panelBuffer() As Variant
Private panelPart As Long, panelRow As Long, bufferN As Long, runPhase As String
Private Const CHUNK As Long = 5000
Private Const PCOLS As Long = 33

Public Sub RefreshASEAN()
    Dim oldCalc As XlCalculation, oldScreen As Boolean, oldEvents As Boolean
    Dim errMsg As String, k As Variant, s As Object, totalRows As Double
    On Error GoTo Failed
    oldCalc = Application.Calculation: oldScreen = Application.ScreenUpdating
    oldEvents = Application.EnableEvents
    Application.ScreenUpdating = False: Application.EnableEvents = False
    Application.Calculation = xlCalculationManual
    runPhase = "Load configuration"
    Initialise
    runPhase = "Read SP"
    ReadSP
    runPhase = "Read MarkLines"
    ReadML
    If series.Count = 0 Then Err.Raise vbObjectError + 701, , "No model rows loaded. Check ImportsML."
    monthKeys = SortedKeys(months)
    runPhase = "Match models"
    For Each k In series.Keys
        Set s = series(k): MatchSeries s
    Next k
    runPhase = "Write panel"
    StartPanel
    For Each k In series.Keys
        Set s = series(k): WriteSeries s
        totalRows = totalRows + UBound(monthKeys) + 1
        If totalRows Mod 50000 < UBound(monthKeys) + 1 Then
            Application.StatusBar = "ASEAN rows: " & Format(totalRows, "#,##0")
            DoEvents
        End If
    Next k
    FlushPanel
    FormatPanel panelWs, panelRow - 1
    runPhase = "Write summaries"
    WriteOutputs
    InvalidateDashboard
    ThisWorkbook.Worksheets("Settings").Range("F2").Value = Now
    ThisWorkbook.Worksheets("Settings").Range("F2").NumberFormat = "yyyy-mm-dd hh:mm"
    Application.Calculation = oldCalc: Application.ScreenUpdating = oldScreen
    Application.EnableEvents = oldEvents: Application.StatusBar = False
    MsgBox "Refresh complete. Panel rows: " & Format(totalRows, "#,##0") & vbCrLf & _
           "Review, Issues and Audit contain unresolved items. Outputs are snapshots.", vbInformation
    Exit Sub
Failed:
    errMsg = "Refresh stopped at " & runPhase & ": " & Err.Description & vbCrLf & _
             "Output sheets may be incomplete. Fix the input and run RefreshASEAN again."
    Application.Calculation = oldCalc: Application.ScreenUpdating = oldScreen
    Application.EnableEvents = oldEvents: Application.StatusBar = False
    MsgBox errMsg, vbExclamation
End Sub

Private Sub InvalidateDashboard()
    Dim w As Worksheet, co As ChartObject, lastData As Long
    Set w = Ws("Dashboard")
    lastData = w.Cells(w.Rows.Count, 1).End(xlUp).Row
    If lastData >= 13 Then w.Range("A13:L" & lastData).ClearContents
    For Each co In w.ChartObjects: co.Delete: Next co
    w.Range("A3").Value = Txt(CfgV("DatasetLabel", "USER INPUT"))
    w.Range("A11").Value = "Chart pending"
    w.Range("B11").Value = "Run BuildAgeChart"
End Sub

Private Function D() As Object
    Set D = CreateObject("Scripting.Dictionary")
    D.CompareMode = vbTextCompare
End Function

Private Function Txt(ByVal v As Variant) As String
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then Exit Function
    Txt = Trim$(CStr(v))
End Function

Private Function Norm(ByVal v As Variant) As String
    Dim x As Variant, t As String
    t = UCase$(Txt(v))
    t = Replace(t, ChrW(12288), " ")
    t = Replace(t, ChrW(160), " ")
    For Each x In Array(" ", "-", "_", ".", "/", "\", "(", ")", ":", vbTab, vbCr, vbLf)
        t = Replace(t, CStr(x), "")
    Next x
    Norm = t
End Function

Private Function Key(ByVal a As String, ByVal b As String, ByVal c As String) As String
    Key = Replace(a, "|", "_") & "|" & Replace(b, "|", "_") & "|" & Replace(c, "|", "_")
End Function

Private Function Yes(ByVal v As Variant) As Boolean
    Yes = (Norm(v) = "YES" Or Norm(v) = "TRUE" Or Norm(v) = "1")
End Function

Private Function CfgV(ByVal name As String, Optional ByVal fallback As Variant = "") As Variant
    If cfg.Exists(name) Then CfgV = cfg(name) Else CfgV = fallback
End Function

Private Sub Issue(ByVal severity As String, ByVal target As String, ByVal code As String, ByVal detail As String)
    logs.Add Array(severity, target, code, detail)
End Sub

Private Function Ws(ByVal name As String) As Worksheet
    On Error Resume Next
    Set Ws = ThisWorkbook.Worksheets(name)
    On Error GoTo 0
    If Ws Is Nothing Then Err.Raise vbObjectError + 702, , "Missing sheet: " & name
End Function

Private Function OutputWs(ByVal name As String) As Worksheet
    Dim w As Worksheet, ch As ChartObject
    On Error Resume Next
    Set w = ThisWorkbook.Worksheets(name)
    On Error GoTo 0
    If w Is Nothing Then
        Set w = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
        w.name = name
    Else
        Do While w.ListObjects.Count > 0
            w.ListObjects(1).Unlist
        Loop
        w.Cells.Clear
        For Each ch In w.ChartObjects
            ch.Delete
        Next ch
    End If
    Set OutputWs = w
End Function

Private Function IsOutputName(ByVal name As String) As Boolean
    Select Case UCase$(name)
        Case "AGESUMMARY", "COHORTSUMMARY", "REVIEW", "AUDIT", "ISSUES", "AGEMATRIX", "SPANNUALCHECK", "DASHBOARD"
            IsOutputName = True
        Case Else
            IsOutputName = (UCase$(name) Like "PANEL_###")
    End Select
End Function

Private Sub Initialise()
    Dim a As Variant, r As Long, w As Worksheet, k As String, f As String
    Set cfg = D(): Set rules = D(): Set families = D(): Set blocks = D()
    Set series = D(): Set crosswalk = D(): Set origins = D(): Set audit = D()
    Set summaries = D(): Set cohorts = D(): Set cohortSeen = D(): Set annualML = D()
    Set months = D(): Set manualEvents = D(): Set logs = New Collection: Set reviews = New Collection
    a = Ws("Settings").Range("A1").CurrentRegion.Value2
    For r = 2 To UBound(a, 1)
        k = Txt(a(r, 1))
        If Len(k) > 0 Then
            If cfg.Exists(k) Then Err.Raise vbObjectError + 703, , "Duplicate setting: " & k
            cfg.Add k, a(r, 2)
        End If
    Next r
    If IsOutputName(Txt(CfgV("SPSheet", "SP_Raw"))) Then _
        Err.Raise vbObjectError + 737, , "SP source cannot use a reserved output name."
    If CLng(CfgV("LaunchPersistence", 3)) < 1 Or CLng(CfgV("ZeroLookback", 6)) < 1 Then _
        Err.Raise vbObjectError + 704, , "LaunchPersistence and ZeroLookback must be positive."
    If CDbl(CfgV("PositiveThreshold", 1)) <= 0 Then _
        Err.Raise vbObjectError + 705, , "PositiveThreshold must be positive."
    If Yes(CfgV("SPAgeConfirmed", "NO")) Then
        If Norm(CfgV("SPAgeConvention", "")) <> "ZEROBASED" And Norm(CfgV("SPAgeConvention", "")) <> "ONEBASED" Then _
            Err.Raise vbObjectError + 741, , "SPAgeConvention must be ZERO_BASED or ONE_BASED."
        If Norm(CfgV("SPAgeScope", "")) <> "GENERATION" And Norm(CfgV("SPAgeScope", "")) <> "NAMEPLATE" Then _
            Err.Raise vbObjectError + 742, , "SPAgeScope must be confirmed as GENERATION or NAMEPLATE."
    End If
    If Yes(CfgV("SPDatesConfirmed", "NO")) Then
        If Norm(CfgV("SPDateScope", "")) <> "GENERATION" And Norm(CfgV("SPDateScope", "")) <> "NAMEPLATE" Then _
            Err.Raise vbObjectError + 743, , "SPDateScope must be GENERATION or NAMEPLATE."
    End If
    a = Ws("Aliases").Range("A1").CurrentRegion.Value2
    For r = 2 To UBound(a, 1)
        If Yes(a(r, 4)) Then
            k = Key(Norm(a(r, 1)), "", Norm(a(r, 2)))
            If rules.Exists(k) Then Err.Raise vbObjectError + 706, , "Duplicate alias: " & k
            rules.Add k, Norm(a(r, 3))
        End If
    Next r
    a = Ws("Crosswalk").Range("A1").CurrentRegion.Value2
    For r = 2 To UBound(a, 1)
        If Yes(a(r, 5)) Then
            k = RawKey(a(r, 1), a(r, 2), a(r, 3))
            If crosswalk.Exists(k) Then Err.Raise vbObjectError + 707, , "Duplicate crosswalk: " & k
            crosswalk.Add k, Array(Txt(a(r, 4)), Yes(a(r, 6)))
        End If
    Next r
    a = Ws("OriginMap").Range("A1").CurrentRegion.Value2
    For r = 2 To UBound(a, 1)
        If Yes(a(r, 3)) Then
            k = Norm(a(r, 1))
            If origins.Exists(k) Then Err.Raise vbObjectError + 708, , "Duplicate origin group: " & k
            origins.Add k, Txt(a(r, 2))
        End If
    Next r
    a = Ws("Events").Range("A1").CurrentRegion.Value2
    For r = 2 To UBound(a, 1)
        If Yes(a(r, 8)) Then
            f = Txt(a(r, 1))
            If Len(f) = 0 Then Err.Raise vbObjectError + 709, , "Events needs SPFamilyID."
            If Not manualEvents.Exists(f) Then
                Dim ec As Collection
                Set ec = New Collection: manualEvents.Add f, ec
            End If
            Dim ev As Object
            Set ev = D()
            ev.Add "Program", Txt(a(r, 2))
            ev.Add "Start", MonthSerial(a(r, 3))
            ev.Add "End", MonthSerial(a(r, 4))
            ev.Add "Source", Txt(a(r, 6))
            ev.Add "Separable", Yes(a(r, 7))
            ev.Add "Metric", UCase$(Txt(a(r, 9)))
            If ev("Metric") <> "SALES" And ev("Metric") <> "PRODUCTION" Then _
                Err.Raise vbObjectError + 740, , "Confirmed Events requires SALES or PRODUCTION in Metric."
            If Norm(a(r, 5)) <> "GENERATION" Or CLng(ev("Start")) = 0 Or Len(Txt(ev("Source"))) = 0 Then _
                Err.Raise vbObjectError + 710, , "Confirmed Events requires GENERATION, valid start and source."
            If CLng(ev("End")) > 0 And CLng(ev("End")) <= CLng(ev("Start")) Then _
                Err.Raise vbObjectError + 711, , "Events end must be AFTER start (exclusive)."
            manualEvents(f).Add ev
        End If
    Next r
End Sub

Private Function Canon(ByVal kind As String, ByVal value As Variant) As String
    Dim k As String, n As String
    n = Norm(value): k = Key(kind, "", n)
    If rules.Exists(k) Then Canon = rules(k) Else Canon = n
End Function

Private Function Country(ByVal value As Variant) As String
    Dim n As String
    n = Canon("COUNTRY", value)
    Select Case n
        Case "TH", "THA", "THAILAND": n = "THAILAND"
        Case "ID", "IDN", "INDONESIA": n = "INDONESIA"
        Case "MY", "MYS", "MALAYSIA": n = "MALAYSIA"
        Case "VN", "VNM", "VIETNAM": n = "VIETNAM"
        Case "PH", "PHL", "PHILIPPINES": n = "PHILIPPINES"
        Case "SG", "SGP", "SINGAPORE": n = "SINGAPORE"
        Case "KH", "KHM", "CAMBODIA": n = "CAMBODIA"
        Case "LA", "LAO", "LAOS": n = "LAOS"
        Case "MM", "MMR", "MYANMAR": n = "MYANMAR"
        Case "BN", "BRN", "BRUNEI": n = "BRUNEI"
    End Select
    Country = n
End Function

Private Function RawKey(ByVal countryV As Variant, ByVal brand As Variant, ByVal model As Variant) As String
    RawKey = Key(Country(countryV), Canon("BRAND", brand), Norm(model))
End Function

Private Function MonthSerial(ByVal v As Variant) As Long
    Dim t As String, yy As Long, mm As Long, n As Double, dt As Date
    On Error GoTo Bad
    If IsError(v) Or IsEmpty(v) Then Exit Function
    t = Txt(v)
    If Len(t) = 0 Then Exit Function
    If IsNumeric(t) Then
        n = CDbl(t)
        If n = Fix(n) And n >= 190001 And n <= 220012 Then
            yy = CLng(n) \ 100: mm = CLng(n) Mod 100
        ElseIf n >= 20000 And n < 100000 Then
            dt = DateSerial(1899, 12, 30) + n
            yy = Year(dt): mm = Month(dt)
        Else
            Exit Function
        End If
    Else
        t = Replace(Replace(t, "/", "-"), ".", "-")
        If Len(t) >= 7 And Mid$(t, 5, 1) = "-" And IsNumeric(Left$(t, 4)) And IsNumeric(Mid$(t, 6, 2)) Then
            yy = CLng(Left$(t, 4)): mm = CLng(Mid$(t, 6, 2))
        Else
            Exit Function
        End If
    End If
    If yy < 1900 Or yy > 2200 Or mm < 1 Or mm > 12 Then Exit Function
    MonthSerial = CLng(DateSerial(yy, mm, 1))
Bad:
End Function

Private Function Age0(ByVal monthV As Long, ByVal launch As Long) As Long
    Age0 = DateDiff("m", CDate(launch), CDate(monthV))
End Function

Private Function NumValue(ByVal v As Variant, ByRef n As Double) As Boolean
    If IsError(v) Or IsEmpty(v) Or VarType(v) = vbBoolean Then Exit Function
    If Len(Txt(v)) = 0 Then Exit Function
    If IsNumeric(v) Then n = CDbl(v): NumValue = True
End Function

Private Function Headers(ByVal a As Variant, ByVal headerRow As Long) As Object
    Dim dct As Object, c As Long, k As String
    Set dct = D()
    For c = 1 To UBound(a, 2)
        k = Norm(a(headerRow, c))
        If Len(k) > 0 Then
            If dct.Exists(k) Then Err.Raise vbObjectError + 712, , "Duplicate header: " & Txt(a(headerRow, c))
            dct.Add k, c
        End If
    Next c
    Set Headers = dct
End Function

Private Function Col(ByVal h As Object, ByVal name As String, Optional ByVal required As Boolean = True) As Long
    If h.Exists(Norm(name)) Then
        Col = CLng(h(Norm(name)))
    ElseIf required Then
        Err.Raise vbObjectError + 713, , "Header not found: " & name
    End If
End Function

Private Function CellV(ByVal a As Variant, ByVal r As Long, ByVal c As Long) As Variant
    If c > 0 Then CellV = a(r, c)
End Function

Private Sub ReadSP()
    Dim w As Worksheet, r As Long, hr As Long, countryN As String, brandN As String, salesN As String
    Dim globalN As String, fid As String, block As String, fam As Object, rec As Object
    Dim startM As Long, endM As Long, ageN As Double, anchor As Long, n As Double
    Dim ageCol As Long, startCol As Long, endCol As Long, anchorCol As Long, y As Long, yc As Long
    Set w = Ws(Txt(CfgV("SPSheet", "SP_Raw")))
    hr = CLng(CfgV("SPHeaderRow", 1))
    spData = w.UsedRange.Value2
    If w.UsedRange.Row <> 1 Or w.UsedRange.Column <> 1 Then _
        Err.Raise vbObjectError + 714, , "SP input must begin at A1."
    If hr < 1 Or hr >= UBound(spData, 1) Then Err.Raise vbObjectError + 715, , "SPHeaderRow is invalid/no SP data."
    Set spCols = Headers(spData, hr)
    Col spCols, "VS:Country/territory": Col spCols, "VS:Sales Brand"
    Col spCols, "VS:Sales Nameplate": Col spCols, "VS:Global Nameplate"
    ageCol = Col(spCols, "VS: Month(s) in Market", False)
    startCol = Col(spCols, Txt(CfgV("SPStartHeader", "LocalLaunchMonth")), False)
    endCol = Col(spCols, Txt(CfgV("SPEndHeader", "LocalEndMonthExclusive")), False)
    anchorCol = Col(spCols, "AgeAnchorMonth", False)
    For r = hr + 1 To UBound(spData, 1)
        countryN = Country(CellV(spData, r, Col(spCols, "VS:Country/territory")))
        brandN = Canon("BRAND", CellV(spData, r, Col(spCols, "VS:Sales Brand")))
        salesN = Txt(CellV(spData, r, Col(spCols, "VS:Sales Nameplate")))
        globalN = Txt(CellV(spData, r, Col(spCols, "VS:Global Nameplate")))
        If Len(countryN & brandN & salesN & globalN) = 0 Then GoTo NextSP
        If Len(countryN) = 0 Or Len(brandN) = 0 Or Len(salesN) = 0 Then
            Issue "WARN", "SP row " & r, "MISSING_SP_KEY", "Country, sales brand or sales nameplate missing."
            GoTo NextSP
        End If
        fid = Key(countryN, brandN, Norm(salesN)) & "|" & Replace(Norm(globalN), "|", "_")
        If Not families.Exists(fid) Then
            Set fam = D(): fam.Add "Country", countryN: fam.Add "Brand", brandN
            fam.Add "SalesName", salesN: fam.Add "GlobalName", globalN: fam.Add "Rows", ""
            Dim rc As Collection, years As Object
            Set rc = New Collection: Set years = D()
            fam.Add "Records", rc: fam.Add "Years", years
            families.Add fid, fam
            block = Key(countryN, brandN, "")
            If Not blocks.Exists(block) Then
                Dim bc As Collection
                Set bc = New Collection: blocks.Add block, bc
            End If
            blocks(block).Add fid
        End If
        Set fam = families(fid)
        fam("Rows") = AppendText(CStr(fam("Rows")), CStr(r))
        Set rec = D()
        rec.Add "Row", r
        rec.Add "Program", Txt(CellV(spData, r, Col(spCols, "VS:Program", False)))
        rec.Add "Origin", Txt(CellV(spData, r, Col(spCols, "VS:Regional Origin", False)))
        rec.Add "Lifecycle", CellV(spData, r, Col(spCols, "VS:Vehicle life cycle in Month", False))
        startM = 0: endM = 0: anchor = 0
        rec.Add "DateSource", "UNCONFIRMED": rec.Add "Scope", "NONE"
        If Yes(CfgV("SPDatesConfirmed", "NO")) Then
            startM = MonthSerial(CellV(spData, r, startCol))
            endM = MonthSerial(CellV(spData, r, endCol))
            If startM > 0 Then rec("DateSource") = "SP_EXPLICIT": rec("Scope") = Norm(CfgV("SPDateScope", "NONE"))
        End If
        If startM = 0 And Yes(CfgV("SPAgeConfirmed", "NO")) Then
            anchor = MonthSerial(CellV(spData, r, anchorCol))
            If anchor = 0 Then anchor = MonthSerial(CfgV("SPAgeAnchorMonth", ""))
            If NumValue(CellV(spData, r, ageCol), ageN) Then
                If ageN >= 0 And ageN = Fix(ageN) And anchor > 0 Then
                    If Norm(CfgV("SPAgeConvention", "ZERO_BASED")) = "ONEBASED" Then ageN = ageN - 1
                    If ageN >= 0 Then
                        startM = CLng(DateAdd("m", -ageN, CDate(anchor)))
                        rec("DateSource") = "SP_AGE_BACKCALC": rec("Scope") = Norm(CfgV("SPAgeScope", "NONE"))
                    End If
                End If
            End If
        End If
        If startM > 0 And endM > 0 And endM <= startM Then _
            Err.Raise vbObjectError + 716, , "SP row " & r & ": end month must be after start month."
        rec.Add "Start", startM: rec.Add "End", endM
        rec.Add "HistoryConflict", False
        For y = 2010 To CLng(CfgV("SPMaxActualYear", 2025))
            yc = Col(spCols, "CY" & y, False)
            If NumValue(CellV(spData, r, yc), n) Then
                If Not fam("Years").Exists(CStr(y)) Then fam("Years").Add CStr(y), 0#
                fam("Years")(CStr(y)) = CDbl(fam("Years")(CStr(y))) + n
                If startM > 0 And y < Year(CDate(startM)) And n > 0 Then rec("HistoryConflict") = True
            End If
        Next y
        If rec("HistoryConflict") Then Issue "WARN", fid, "SP_HISTORY_BEFORE_START", "SP row " & r & " has annual sales before its derived start; historical generation coverage needs review."
        fam("Records").Add rec
NextSP:
    Next r
    If families.Count = 0 Then Err.Raise vbObjectError + 717, , "No usable SP families."
    Dim eventKey As Variant
    For Each eventKey In manualEvents.Keys
        If Not families.Exists(eventKey) Then Issue "WARN", CStr(eventKey), "EVENT_FAMILY_NOT_FOUND", "Event does not match current SP families."
    Next eventKey
End Sub

Private Function AppendText(ByVal existing As String, ByVal v As String) As String
    If Len(v) = 0 Then AppendText = existing: Exit Function
    If InStr(1, ";" & existing & ";", ";" & v & ";", vbTextCompare) > 0 Then AppendText = existing: Exit Function
    If Len(existing) = 0 Then AppendText = v Else AppendText = existing & ";" & v
End Function

Private Sub ReadML()
    Dim imp As Variant, a As Variant, ir As Long, r As Long, c As Long, hr As Long
    Dim w As Worksheet, h As Object, mcols As Object, rowMonths As Object, s As Object
    Dim co As String, br As String, mo As String, metric As String, basis As String, sk As String
    Dim grp As String, nat As String, n As Double, mk As Variant, ms As Long, vals As Object
    Dim ctryCol As Long, groupCol As Long, natCol As Long, typeCol As Long, segCol As Long, ptCol As Long
    Dim naturalSeen As Object, nk As String, latest As Long, valueA As Variant
    Set naturalSeen = D()
    latest = MonthSerial(CfgV("MLLastActualMonth", ""))
    If latest = 0 Then Err.Raise vbObjectError + 718, , "Set MLLastActualMonth (fixed source reporting month, YYYY-MM)."
    imp = Ws("ImportsML").Range("A1").CurrentRegion.Value2
    For ir = 2 To UBound(imp, 1)
        If Not Yes(imp(ir, 6)) Then GoTo NextImport
        If IsOutputName(Txt(imp(ir, 1))) Then Err.Raise vbObjectError + 738, , "ML source cannot use a reserved output name."
        Set w = Ws(Txt(imp(ir, 1))): hr = CLng(imp(ir, 5))
        metric = UCase$(Txt(imp(ir, 3))): basis = UCase$(Txt(imp(ir, 4)))
        If metric <> "SALES" And metric <> "PRODUCTION" Then Err.Raise vbObjectError + 719, , "ImportsML Metric must be SALES or PRODUCTION."
        If Len(basis) = 0 Then Err.Raise vbObjectError + 720, , "ImportsML needs Basis (e.g. WHOLESALE, REGISTRATION, PRODUCTION)."
        If metric = "PRODUCTION" And basis <> "PRODUCTION" Then Err.Raise vbObjectError + 721, , "Production input requires PRODUCTION basis."
        a = w.UsedRange.Value2
        If w.UsedRange.Row <> 1 Or w.UsedRange.Column <> 1 Then Err.Raise vbObjectError + 722, , "MarkLines input must begin at A1: " & w.name
        If hr < 1 Or hr >= UBound(a, 1) Then Err.Raise vbObjectError + 723, , "Invalid header row/no data: " & w.name
        Set h = Headers(a, hr): Set mcols = D()
        Col h, "Maker_Brand": Col h, "Model"
        ctryCol = Col(h, "Country", False)
        If ctryCol = 0 Then ctryCol = Col(h, "Country/territory", False)
        groupCol = Col(h, "Group", False): natCol = Col(h, "Nationality", False)
        typeCol = Col(h, "Type", False): segCol = Col(h, "Segment", False)
        ptCol = Col(h, "Power Train", False)
        For c = 1 To UBound(a, 2)
            ms = MonthSerial(a(hr, c))
            If ms > 0 And ms <= latest Then
                If mcols.Exists(CStr(ms)) Then Err.Raise vbObjectError + 724, , "Duplicate month in " & w.name
                mcols.Add CStr(ms), c
                If Not months.Exists(CStr(ms)) Then months.Add CStr(ms), ms
            End If
        Next c
        If mcols.Count = 0 Then Err.Raise vbObjectError + 725, , "No YYYYMM/ISO month headers within actual period in " & w.name
        For r = hr + 1 To UBound(a, 1)
            co = Country(CellV(a, r, ctryCol))
            If Len(co) = 0 Then co = Country(imp(ir, 2))
            br = Canon("BRAND", CellV(a, r, Col(h, "Maker_Brand")))
            mo = Txt(CellV(a, r, Col(h, "Model")))
            If Len(br & mo) = 0 Then GoTo NextMLRow
            If Len(co) = 0 Or Len(br) = 0 Or Len(mo) = 0 Then Err.Raise vbObjectError + 726, , "Missing country/brand/model: " & w.name & " row " & r
            If Norm(mo) = "TOTAL" Or Norm(mo) = "SUBTOTAL" Or Norm(mo) = "GRANDTOTAL" Then
                Issue "INFO", w.name & " row " & r, "TOTAL_EXCLUDED", "Subtotal row is excluded; do not include source subtotals in model rows."
                GoTo NextMLRow
            End If
            grp = Txt(CellV(a, r, groupCol)): nat = Txt(CellV(a, r, natCol))
            sk = RawKey(co, br, mo) & "|" & metric & "|" & Replace(basis, "|", "_")
            nk = sk & "|" & Key(Norm(grp), Norm(nat), Norm(CellV(a, r, typeCol))) & "|" & _
                 Key(Norm(CellV(a, r, segCol)), Norm(CellV(a, r, ptCol)), "")
            If naturalSeen.Exists(nk) Then Err.Raise vbObjectError + 727, , "Duplicate ML attributes: " & w.name & " row " & r & ". Aggregate omitted trims first, or remove duplicate imports."
            naturalSeen.Add nk, True
            If Not series.Exists(sk) Then
                Set s = D(): Set vals = D(): Set rowMonths = D()
                s.Add "Key", sk: s.Add "RawKey", RawKey(co, br, mo)
                s.Add "Country", co: s.Add "Brand", br: s.Add "Model", mo
                s.Add "Metric", metric: s.Add "Basis", basis: s.Add "Group", grp: s.Add "Nationality", nat
                s.Add "Type", "": s.Add "Segment", "": s.Add "Powertrain", "": s.Add "Lineage", ""
                s.Add "Values", vals: s.Add "Counts", rowMonths: s.Add "RowCount", 0&
                series.Add sk, s
            End If
            Set s = series(sk)
            If s("Group") <> grp Or s("Nationality") <> nat Then Err.Raise vbObjectError + 728, , "Inconsistent Group/Nationality within " & sk
            s("Type") = AppendText(CStr(s("Type")), Txt(CellV(a, r, typeCol)))
            s("Segment") = AppendText(CStr(s("Segment")), Txt(CellV(a, r, segCol)))
            s("Powertrain") = AppendText(CStr(s("Powertrain")), Txt(CellV(a, r, ptCol)))
            s("Lineage") = AppendText(CStr(s("Lineage")), w.name & "!" & r)
            s("RowCount") = CLng(s("RowCount")) + 1
            For Each mk In mcols.Keys
                valueA = a(r, CLng(mcols(mk)))
                If NumValue(valueA, n) Then
                    If n < 0 Or n <> Fix(n) Then Err.Raise vbObjectError + 729, , "Invalid units (negative/fractional): " & w.name & " row " & r & " month " & Format(CDate(CLng(mk)), "yyyy-mm")
                    If Not s("Values").Exists(mk) Then s("Values").Add mk, 0#: s("Counts").Add mk, 0&
                    s("Values")(mk) = CDbl(s("Values")(mk)) + n
                    s("Counts")(mk) = CLng(s("Counts")(mk)) + 1
                    AddAudit co, metric, basis, CLng(mk), n, True
                ElseIf Len(Txt(valueA)) > 0 Or IsError(valueA) Then
                    Issue "WARN", w.name & " row " & r, "NONNUMERIC_MONTH", Format(CDate(CLng(mk)), "yyyy-mm") & " is blanked, not converted to zero."
                End If
            Next mk
NextMLRow:
        Next r
NextImport:
    Next ir
    ' Fill absent calendar months, so sales gaps do not compress model age.
    Dim lo As Long, hi As Long, km As Variant
    For Each km In months.Keys
        If lo = 0 Or CLng(km) < lo Then lo = CLng(km)
        If CLng(km) > hi Then hi = CLng(km)
    Next km
    If lo = 0 Then Exit Sub
    ms = lo
    Do While ms <= hi
        If Not months.Exists(CStr(ms)) Then months.Add CStr(ms), ms: Issue "WARN", "Calendar", "MONTH_HEADER_GAP", Format(CDate(ms), "yyyy-mm") & " is inserted as missing."
        ms = CLng(DateAdd("m", 1, CDate(ms)))
    Loop
End Sub

Private Function Digits(ByVal t As String) As String
    Dim i As Long, ch As String
    For i = 1 To Len(t)
        ch = Mid$(t, i, 1)
        If ch >= "0" And ch <= "9" Then Digits = Digits & ch
    Next i
End Function

Private Function Similarity(ByVal a As String, ByVal b As String) As Double
    Dim i As Long, j As Long, prev() As Long, cur() As Long, cost As Long, best As Long
    a = Norm(a): b = Norm(b)
    If a = b Then Similarity = 1: Exit Function
    If Len(a) = 0 Or Len(b) = 0 Then Exit Function
    ' Digits are model identity cues. Do not propose 3 -> 5 or 03 -> 3 automatically.
    If Digits(a) <> Digits(b) Then Exit Function
    If Len(a) > 120 Or Len(b) > 120 Then Exit Function
    ReDim prev(0 To Len(b)): ReDim cur(0 To Len(b))
    For j = 0 To Len(b): prev(j) = j: Next j
    For i = 1 To Len(a)
        cur(0) = i
        For j = 1 To Len(b)
            cost = 1: If Mid$(a, i, 1) = Mid$(b, j, 1) Then cost = 0
            best = prev(j) + 1
            If cur(j - 1) + 1 < best Then best = cur(j - 1) + 1
            If prev(j - 1) + cost < best Then best = prev(j - 1) + cost
            cur(j) = best
        Next j
        For j = 0 To Len(b): prev(j) = cur(j): Next j
    Next i
    best = Len(a): If Len(b) > best Then best = Len(b)
    Similarity = 1 - prev(Len(b)) / best
End Function

Private Sub MatchSeries(ByVal s As Object)
    Dim rk As String, block As String, fid As Variant, fam As Object, score As Double, alt As Double
    Dim exactN As Long, exactID As String, topID(1 To 3) As String, topScore(1 To 3) As Double
    Dim i As Long, j As Long, cw As Variant, method As String, selected As String
    rk = CStr(s("RawKey")): block = Key(CStr(s("Country")), CStr(s("Brand")), "")
    s.Add "FitApproved", False
    If crosswalk.Exists(rk) Then
        cw = crosswalk(rk): selected = CStr(cw(0))
        If families.Exists(selected) Then
            Set fam = families(selected)
            If fam("Country") = s("Country") And fam("Brand") = s("Brand") Then
                method = "APPROVED_ALIAS": s("FitApproved") = CBool(cw(1))
                GoTo DoneMatch
            End If
        End If
        Issue "WARN", rk, "STALE_OR_WRONG_CROSSWALK", "Approved family not found or country/brand differs. Correct brand alias separately."
        selected = ""
    End If
    If Not blocks.Exists(block) Then method = "NO_COUNTRY_BRAND_BLOCK": GoTo DoneMatch
    For Each fid In blocks(block)
        Set fam = families(fid)
        score = Similarity(CStr(s("Model")), CStr(fam("SalesName")))
        alt = Similarity(CStr(s("Model")), CStr(fam("GlobalName")))
        If alt > score Then score = alt
        If Norm(s("Model")) = Norm(fam("SalesName")) Or Norm(s("Model")) = Norm(fam("GlobalName")) Then
            exactN = exactN + 1: exactID = CStr(fid)
        End If
        For i = 1 To 3
            If score > topScore(i) Then
                For j = 3 To i + 1 Step -1
                    topScore(j) = topScore(j - 1): topID(j) = topID(j - 1)
                Next j
                topScore(i) = score: topID(i) = CStr(fid): Exit For
            End If
        Next i
    Next fid
    If exactN = 1 Then
        selected = exactID: method = "EXACT_UNIQUE"
    Else
        method = "REVIEW_NAME"
        If exactN > 1 Then method = "REVIEW_MULTIPLE_EXACT"
        For i = 1 To 3
            If Len(topID(i)) > 0 Then
                Set fam = families(topID(i))
                reviews.Add Array(rk, s("Country"), s("Brand"), s("Model"), i, topID(i), _
                    fam("SalesName"), fam("GlobalName"), topScore(i), fam("Rows"), method, "")
            End If
        Next i
        If Len(topID(1)) = 0 Then Issue "WARN", rk, "NO_SIMILAR_NAME", "Country/brand exists, but model names or digits differ. Add an independently verified crosswalk."
    End If
DoneMatch:
    s.Add "SPID", selected: s.Add "Match", method
    If Len(selected) = 0 Then Issue "WARN", rk, "UNMATCHED_MODEL", method
End Sub

Private Function StatusV(ByVal s As Object, ByVal m As Long) As String
    If Not s("Values").Exists(CStr(m)) Then
        StatusV = "MISSING"
    ElseIf CLng(s("Counts")(CStr(m))) < CLng(s("RowCount")) Then
        StatusV = "PARTIAL"
    Else
        StatusV = "OK"
    End If
End Function

Private Sub ObservedLaunch(ByVal s As Object, ByRef first As Long, ByRef launch As Long, ByRef state As String)
    Dim m As Variant, idx As Long, lookback As Long, persist As Long, j As Long, pm As Long
    Dim threshold As Double, valid As Boolean
    first = 0: launch = 0: state = "NO_POSITIVE_SALES"
    If s("Metric") <> "SALES" Then state = "PRODUCTION_NOT_SALES_LAUNCH": Exit Sub
    threshold = CDbl(CfgV("PositiveThreshold", 1))
    For idx = 0 To UBound(monthKeys)
        m = monthKeys(idx)
        If s("Values").Exists(CStr(m)) Then
            If CDbl(s("Values")(CStr(m))) >= threshold Then first = CLng(m): Exit For
        End If
    Next idx
    If first = 0 Then Exit Sub
    lookback = CLng(CfgV("ZeroLookback", 6)): persist = CLng(CfgV("LaunchPersistence", 3))
    If idx < lookback Then state = "LEFT_CENSORED_OR_SHORT_HISTORY": Exit Sub
    For j = 1 To lookback
        pm = CLng(DateAdd("m", -j, CDate(first)))
        If StatusV(s, pm) <> "OK" Then state = "PREHISTORY_MISSING": Exit Sub
        If CDbl(s("Values")(CStr(pm))) <> 0 Then state = "PREHISTORY_NONZERO": Exit Sub
    Next j
    For j = 0 To persist - 1
        pm = CLng(DateAdd("m", j, CDate(first)))
        If StatusV(s, pm) <> "OK" Then state = "PERSISTENCE_MISSING": Exit Sub
        If CDbl(s("Values")(CStr(pm))) < threshold Then state = "FIRST_POSITIVE_NOT_SUSTAINED": Exit Sub
    Next j
    launch = first: state = "SUSTAINED_FIRST_OBSERVED_PROXY"
    ' Never reset launch after a later zero-sales gap.
End Sub

Private Sub Generation(ByVal s As Object, ByVal m As Long, ByRef start As Long, ByRef program As String, _
                       ByRef status As String, ByRef eligible As Boolean, ByRef nameStart As Long)
    Dim fid As String, fam As Object, rec As Object, ev As Object, active As Object
    Dim ek As String, k As Variant, chosen As Object, st As Long, en As Long, conflict As Boolean
    start = 0: nameStart = 0: program = "": eligible = False: status = "NO_VERIFIED_GENERATION_DATE"
    fid = CStr(s("SPID"))
    If Len(fid) = 0 Then status = "UNMATCHED": Exit Sub
    Set active = D(): Set fam = families(fid)
    If manualEvents.Exists(fid) Then
        For Each ev In manualEvents(fid)
            st = CLng(ev("Start")): en = CLng(ev("End"))
            If ev("Metric") = s("Metric") And m >= st And (en = 0 Or m < en) Then
                ek = Key(CStr(ev("Program")), CStr(st), CStr(en))
                If Not active.Exists(ek) Then active.Add ek, ev
            End If
        Next ev
        If active.Count = 1 Then
            k = active.Keys: Set chosen = active(k(0))
            start = CLng(chosen("Start")): program = CStr(chosen("Program")): status = "VERIFIED_EVENT"
            eligible = CBool(chosen("Separable")): Exit Sub
        End If
        If active.Count > 1 Then status = "GENERATION_OVERLAP": Exit Sub
        status = "OUTSIDE_VERIFIED_EVENT_WINDOWS": Exit Sub
    End If
    If s("Metric") = "PRODUCTION" Then status = "PRODUCTION_START_METADATA_REQUIRED": Exit Sub
    For Each rec In fam("Records")
        st = CLng(rec("Start")): en = CLng(rec("End"))
        If st > 0 Then
            If rec("Scope") = "NAMEPLATE" And m >= st Then
                If nameStart = 0 Or st < nameStart Then nameStart = st
            End If
            If rec("Scope") = "GENERATION" And m >= st And (en = 0 Or m < en) Then
                ek = Key(CStr(rec("Program")), CStr(st), CStr(en))
                If Not active.Exists(ek) Then active.Add ek, rec
                If rec("HistoryConflict") Then conflict = True
            End If
        End If
    Next rec
    If active.Count = 1 Then
        k = active.Keys: Set chosen = active(k(0))
        start = CLng(chosen("Start")): program = CStr(chosen("Program")): status = CStr(chosen("DateSource"))
        eligible = CBool(s("FitApproved")) And Not conflict
        If conflict Then status = status & "_HISTORY_CONFLICT"
    ElseIf active.Count > 1 Then
        status = "GENERATION_OVERLAP"
    End If
End Sub

Private Function Band(ByVal age As Variant) As String
    If IsEmpty(age) Then Band = "UNKNOWN": Exit Function
    If CLng(age) < 0 Then Band = "PRELAUNCH": Exit Function
    If CLng(age) >= 72 Then Band = "7PLUS" Else Band = "Y" & (CLng(age) \ 12 + 1)
End Function

Private Sub StartPanel()
    Dim w As Worksheet, name As String
    ' Remove stale panel fragments only; never mutate raw/config/mapping sheets.
    For Each w In ThisWorkbook.Worksheets
        If UCase$(w.name) Like "PANEL_###" Then
            Do While w.ListObjects.Count > 0: w.ListObjects(1).Unlist: Loop
            w.Cells.Clear
        End If
    Next w
    panelPart = 1: panelRow = 2: bufferN = 0
    ReDim panelBuffer(1 To CHUNK, 1 To PCOLS)
    Set panelWs = OutputWs("Panel_001")
    WriteHeader panelWs, PanelHeaders
End Sub

Private Function PanelHeaders() As Variant
    PanelHeaders = Array("Country", "Group", "MLNationality", "AnalysisOrigin", "MakerBrand", "MLModel", _
        "Type", "Segment", "PowerTrain", "Metric", "Basis", "Month", "UnitsKnown", "VolumeStatus", _
        "MatchMethod", "SPFamilyID", "SPSalesNameplate", "SPGlobalNameplate", "FirstPositiveMonth", _
        "ObservedLaunchMonth", "ObservedAge0", "ObservedStartStatus", "SPProgram", "GenerationStartMonth", _
        "GenerationAge0", "GenerationStatus", "PrimaryAge0", "AgeBasis", "AgeYearBand", "FitEligible", _
        "MLSourceRows", "SPSourceRows", "Alert")
End Function

Private Sub FlushPanel()
    Dim out() As Variant, r As Long, c As Long
    If bufferN = 0 Then Exit Sub
    If panelRow + bufferN - 1 > 1000000 Then
        FormatPanel panelWs, panelRow - 1
        panelPart = panelPart + 1: panelRow = 2
        Set panelWs = OutputWs("Panel_" & Format(panelPart, "000"))
        WriteHeader panelWs, PanelHeaders
    End If
    ReDim out(1 To bufferN, 1 To PCOLS)
    For r = 1 To bufferN
        For c = 1 To PCOLS: out(r, c) = panelBuffer(r, c): Next c
    Next r
    panelWs.Cells(panelRow, 1).Resize(bufferN, PCOLS).Value2 = out
    panelRow = panelRow + bufferN: bufferN = 0
End Sub

Private Sub FormatPanel(ByVal w As Worksheet, ByVal lastRow As Long)
    w.Range("L2:L" & lastRow).NumberFormat = "yyyy-mm"
    w.Range("S2:T" & lastRow).NumberFormat = "yyyy-mm"
    w.Range("X2:X" & lastRow).NumberFormat = "yyyy-mm"
    w.Range("M2:M" & lastRow).NumberFormat = "#,##0"
    w.Range("U2:U" & lastRow).NumberFormat = "0"
    w.Range("Y2:Y" & lastRow).NumberFormat = "0"
    w.Range("AA2:AA" & lastRow).NumberFormat = "0"
    w.Columns("A:AG").ColumnWidth = 20
    w.Columns("P:R").ColumnWidth = 28: w.Columns("AE:AG").ColumnWidth = 32
    If w.AutoFilterMode Then w.AutoFilterMode = False
    w.Range("A1:AG" & lastRow).AutoFilter
End Sub

Private Sub WriteSeries(ByVal s As Object)
    Dim first As Long, obs As Long, obsState As String, mk As Variant, m As Long
    Dim st As Long, nst As Long, prog As String, genState As String, eligible As Boolean
    Dim age As Variant, genAge As Variant, obsAge As Variant, units As Variant, vs As String
    Dim ageBasis As String, ab As String, alert As String, fid As String, fam As Object
    Dim origin As String, rowV As Variant, i As Long
    ObservedLaunch s, first, obs, obsState
    s.Add "First", first: s.Add "Obs", obs: s.Add "ObsStatus", obsState
    origin = CStr(s("Nationality"))
    If origins.Exists(Norm(s("Group"))) Then origin = CStr(origins(Norm(s("Group"))))
    If Len(origin) = 0 Then origin = "UNKNOWN"
    s.Add "Origin", origin
    fid = CStr(s("SPID"))
    If Len(fid) > 0 Then Set fam = families(fid)
    Dim ages As Object
    Set ages = D(): s.Add "Ages", ages
    For Each mk In monthKeys
        m = CLng(mk): vs = StatusV(s, m)
        units = Empty: age = Empty: genAge = Empty: obsAge = Empty
        ageBasis = "UNKNOWN": alert = ""
        If s("Values").Exists(CStr(m)) Then units = CDbl(s("Values")(CStr(m)))
        If obs > 0 And m >= obs Then obsAge = Age0(m, obs)
        Generation s, m, st, prog, genState, eligible, nst
        If st > 0 Then
            genAge = Age0(m, st): age = genAge: ageBasis = "GENERATION"
        ElseIf nst > 0 Then
            age = Age0(m, nst): ageBasis = "SP_NAMEPLATE"
        ElseIf Not IsEmpty(obsAge) And Yes(CfgV("AllowObservedAge", "YES")) Then
            age = obsAge: ageBasis = "FIRST_OBSERVED_PROXY"
        End If
        If s("Metric") = "PRODUCTION" Then
            ' A sales-launch proxy is not a production-launch date.
            eligible = False
            If ageBasis = "FIRST_OBSERVED_PROXY" Then age = Empty: ageBasis = "UNKNOWN"
        End If
        If vs <> "OK" Or IsEmpty(genAge) Or s("Metric") <> "SALES" Then eligible = False
        If first > 0 And st > first And m >= st Then alert = "OLDER_SALES_BEFORE_GENERATION_START"
        If genState = "GENERATION_OVERLAP" Then alert = AppendText(alert, "NO_GENERATION_VOLUME_SPLIT")
        If vs <> "OK" Then alert = AppendText(alert, vs)
        ab = Band(age): ages.Add CStr(m), age
        rowV = Array(s("Country"), s("Group"), s("Nationality"), origin, s("Brand"), s("Model"), _
            s("Type"), s("Segment"), s("Powertrain"), s("Metric"), s("Basis"), m, units, vs, _
            s("Match"), fid, "", "", DateOrBlank(first), DateOrBlank(obs), obsAge, obsState, prog, _
            DateOrBlank(st), genAge, genState, age, ageBasis, ab, IIf(eligible, "YES", "NO"), s("Lineage"), "", alert)
        If Len(fid) > 0 Then rowV(16) = fam("SalesName"): rowV(17) = fam("GlobalName"): rowV(31) = fam("Rows")
        bufferN = bufferN + 1
        For i = 0 To PCOLS - 1: panelBuffer(bufferN, i + 1) = rowV(i): Next i
        If bufferN = CHUNK Then FlushPanel
        If Not IsEmpty(units) Then
            AddAudit CStr(s("Country")), CStr(s("Metric")), CStr(s("Basis")), m, CDbl(units), False, vs, Len(fid) > 0, Not IsEmpty(age)
            AddSummary s, m, ab, CDbl(units), vs, age, ageBasis
            If Not IsEmpty(age) And vs = "OK" Then AddCohort s, CLng(age), CDbl(units), ageBasis, st, prog, nst
        Else
            AddSummary s, m, "UNKNOWN", 0#, vs, age, ageBasis
        End If
        If Len(fid) > 0 And s("Metric") = "SALES" And s("Basis") = UCase$(Txt(CfgV("SPComparableBasis", ""))) Then
            If IsEmpty(units) Then AddAnnual fid, m, 0#, vs Else AddAnnual fid, m, CDbl(units), vs
        End If
    Next mk
End Sub

Private Function DateOrBlank(ByVal n As Long) As Variant
    If n > 0 Then DateOrBlank = n
End Function

Private Sub AddAudit(ByVal co As String, ByVal metric As String, ByVal basis As String, ByVal m As Long, _
                     ByVal units As Double, ByVal inputV As Boolean, Optional ByVal vs As String = "", _
                     Optional ByVal matched As Boolean = False, Optional ByVal aged As Boolean = False)
    Dim k As String, a As Variant
    k = Key(co, metric, basis) & "|" & m
    If Not audit.Exists(k) Then audit.Add k, Array(co, metric, basis, m, 0#, 0#, 0#, 0#, 0#, 0&)
    a = audit(k)
    If inputV Then
        a(4) = CDbl(a(4)) + units
    Else
        a(5) = CDbl(a(5)) + units
        If matched Then a(6) = CDbl(a(6)) + units
        If aged Then a(7) = CDbl(a(7)) + units
        If vs = "PARTIAL" Then a(8) = CDbl(a(8)) + units: a(9) = CLng(a(9)) + 1
    End If
    audit(k) = a
End Sub

Private Sub AddSummary(ByVal s As Object, ByVal m As Long, ByVal bandN As String, ByVal units As Double, ByVal vs As String, ByVal age As Variant, ByVal ageBasis As String)
    Dim k As String, a As Variant, ix As Long
    k = Key(CStr(s("Country")), CStr(s("Origin")), CStr(s("Group"))) & "|" & _
        Key(CStr(s("Brand")), CStr(s("Metric")), CStr(s("Basis"))) & "|" & m & "|" & ageBasis
    If Not summaries.Exists(k) Then summaries.Add k, Array(s("Country"), s("Origin"), s("Group"), s("Brand"), _
        s("Metric"), s("Basis"), m, 0#, 0#, 0#, 0#, 0#, 0#, 0#, 0#, 0&, 0&, 0#, ageBasis)
    a = summaries(k)
    If vs = "MISSING" Then
        a(15) = CLng(a(15)) + 1
    Else
        Select Case bandN
            Case "Y1": ix = 7
            Case "Y2": ix = 8
            Case "Y3": ix = 9
            Case "Y4": ix = 10
            Case "Y5": ix = 11
            Case "Y6": ix = 12
            Case "7PLUS": ix = 13
            Case Else: ix = 14
        End Select
        a(ix) = CDbl(a(ix)) + units
        If Not IsEmpty(age) Then a(17) = CDbl(a(17)) + CLng(age) * units
        If vs = "PARTIAL" Then a(16) = CLng(a(16)) + 1
    End If
    summaries(k) = a
End Sub

Private Sub AddCohort(ByVal s As Object, ByVal age As Long, ByVal units As Double, ByVal basisAge As String, _
                      ByVal generationStart As Long, ByVal program As String, ByVal nameStart As Long)
    Dim k As String, seen As String, a As Variant, entity As String
    k = Key(CStr(s("Country")), CStr(s("Origin")), CStr(s("Metric"))) & "|" & _
        Key(CStr(s("Basis")), basisAge, Format(age, "0000"))
    If Not cohorts.Exists(k) Then cohorts.Add k, Array(s("Country"), s("Origin"), s("Metric"), s("Basis"), basisAge, age, 0#, 0&)
    a = cohorts(k): a(6) = CDbl(a(6)) + units
    entity = CStr(s("SPID"))
    If basisAge = "GENERATION" Then
        entity = entity & "|" & generationStart & "|" & program
    ElseIf basisAge = "SP_NAMEPLATE" Then
        entity = entity & "|" & nameStart
    Else
        entity = CStr(s("RawKey")) & "|" & s("Obs")
    End If
    seen = k & "|" & entity
    If Not cohortSeen.Exists(seen) Then a(7) = CLng(a(7)) + 1: cohortSeen.Add seen, True
    cohorts(k) = a
End Sub

Private Sub AddAnnual(ByVal fid As String, ByVal m As Long, ByVal n As Double, ByVal vs As String)
    Dim k As String, a As Variant, seenKey As String
    k = fid & "|" & Year(CDate(m))
    If Not annualML.Exists(k) Then
        Dim seen As Object
        Set seen = D(): annualML.Add k, Array(fid, Year(CDate(m)), 0#, True, seen)
    End If
    a = annualML(k): a(2) = CDbl(a(2)) + n
    If vs <> "OK" Then a(3) = False
    a(4)(CStr(m)) = True
    annualML(k) = a
End Sub

Private Function SortedKeys(ByVal dct As Object) As Variant
    Dim a As Variant
    a = dct.Keys
    If dct.Count > 1 Then QuickSort a, LBound(a), UBound(a)
    SortedKeys = a
End Function

Private Sub QuickSort(ByRef a As Variant, ByVal lo As Long, ByVal hi As Long)
    Dim i As Long, j As Long, pivot As String, temp As Variant
    i = lo: j = hi: pivot = CStr(a((lo + hi) \ 2))
    Do While i <= j
        Do While CStr(a(i)) < pivot: i = i + 1: Loop
        Do While CStr(a(j)) > pivot: j = j - 1: Loop
        If i <= j Then temp = a(i): a(i) = a(j): a(j) = temp: i = i + 1: j = j - 1
    Loop
    If lo < j Then QuickSort a, lo, j
    If i < hi Then QuickSort a, i, hi
End Sub

Private Sub WriteHeader(ByVal w As Worksheet, ByVal headersV As Variant)
    Dim a() As Variant, i As Long
    ReDim a(1 To 1, 1 To UBound(headersV) + 1)
    For i = 0 To UBound(headersV): a(1, i + 1) = headersV(i): Next i
    w.Cells(1, 1).Resize(1, UBound(headersV) + 1).Value2 = a
    With w.Cells(1, 1).Resize(1, UBound(headersV) + 1)
        .Interior.Color = RGB(34, 55, 78): .Font.Color = vbWhite: .Font.Bold = True
        .WrapText = True: .RowHeight = 34
    End With
    w.Cells(1, 1).Resize(1, UBound(headersV) + 1).Font.name = "Arial"
    w.Cells(1, 1).Resize(1, UBound(headersV) + 1).Font.Size = 10
End Sub

Private Sub WriteCollection(ByVal name As String, ByVal heads As Variant, ByVal data As Collection)
    Dim w As Worksheet, a() As Variant, rowV As Variant, r As Long, c As Long, count As Long
    Set w = OutputWs(name): WriteHeader w, heads
    If data.Count > 0 Then
        If data.Count > 1000000 Then Err.Raise vbObjectError + 730, , name & " exceeds row capacity. Reduce scope."
        ReDim a(1 To data.Count, 1 To UBound(heads) + 1)
        For r = 1 To data.Count
            rowV = data(r)
            For c = 0 To UBound(heads): a(r, c + 1) = rowV(c): Next c
        Next r
        w.Cells(2, 1).Resize(data.Count, UBound(heads) + 1).Value2 = a
        w.Cells(1, 1).Resize(data.Count + 1, UBound(heads) + 1).AutoFilter
    End If
    w.Cells(1, 1).Resize(1, UBound(heads) + 1).EntireColumn.ColumnWidth = 20
End Sub

Private Sub WriteOutputs()
    Dim rows As Collection, k As Variant, a As Variant, r As Long, w As Worksheet
    Set rows = New Collection
    For Each k In SortedKeys(summaries): rows.Add summaries(k): Next k
    WriteCollection "AgeSummary", Array("Country", "AnalysisOrigin", "Group", "Brand", "Metric", "Basis", "Month", _
        "Y1_0to11", "Y2_12to23", "Y3_24to35", "Y4_36to47", "Y5_48to59", "Y6_60to71", "Y7plus_72plus", _
        "AgeUnknownUnits", "MissingModelMonths", "PartialModelMonths", "SumAgeTimesUnits", "AgeBasis"), rows
    Ws("AgeSummary").Columns("G").NumberFormat = "yyyy-mm"
    Ws("AgeSummary").Columns("H:O").NumberFormat = "#,##0"
    Set w = Ws("AgeSummary")
    w.Range("T1:U1").Value = Array("SalesWeightedAgeMonth", "AgeKnownShareOfKnownUnits")
    If rows.Count > 0 Then
        w.Range("T2:T" & rows.Count + 1).FormulaR1C1 = "=IF(SUM(RC[-12]:RC[-6])>0,RC[-2]/SUM(RC[-12]:RC[-6]),"""")"
        w.Range("U2:U" & rows.Count + 1).FormulaR1C1 = "=IF(SUM(RC[-13]:RC[-6])>0,SUM(RC[-13]:RC[-7])/SUM(RC[-13]:RC[-6]),"""")"
        w.Range("T2:T" & rows.Count + 1).NumberFormat = "0.0"
        w.Range("U2:U" & rows.Count + 1).NumberFormat = "0.0%"
    End If
    Set rows = New Collection
    For Each k In SortedKeys(cohorts): rows.Add cohorts(k): Next k
    WriteCollection "CohortSummary", Array("Country", "AnalysisOrigin", "Metric", "Basis", "AgeBasis", "Age0", "Units", "DistinctModelsObserved"), rows
    Set w = Ws("CohortSummary"): w.Range("I1").Value = "UnitsPerObservedModel"
    If rows.Count > 0 Then w.Range("I2:I" & rows.Count + 1).FormulaR1C1 = "=IF(RC[-1]>0,RC[-2]/RC[-1],"""")"
    WriteCollection "Review", Array("RawFamilyKey", "Country", "MLBrand", "MLModel", "Rank", "SPFamilyID", _
        "SPSalesNameplate", "SPGlobalNameplate", "NameSimilarity", "SPSourceRows", "Reason", "Decision"), reviews
    Ws("Review").Columns("A").ColumnWidth = 38: Ws("Review").Columns("F").ColumnWidth = 48
    Ws("Review").Columns("I").NumberFormat = "0.000"
    Set rows = New Collection
    For Each k In SortedKeys(audit)
        a = audit(k)
        rows.Add Array(a(0), a(1), a(2), a(3), a(4), a(5), Empty, a(6), a(7), a(8), a(9))
    Next k
    WriteCollection "Audit", Array("Country", "Metric", "Basis", "Month", "SourceKnownUnits", "PanelKnownUnits", "Difference", _
        "MatchedKnownUnits", "AgeKnownUnits", "PartialKnownUnits", "PartialModelMonths"), rows
    Set w = Ws("Audit"): w.Columns("D").NumberFormat = "yyyy-mm"
    w.Range("L1:M1").Value = Array("MatchedKnownUnitsShare", "AgeKnownUnitsShare")
    If rows.Count > 0 Then
        w.Range("G2:G" & rows.Count + 1).FormulaR1C1 = "=RC[-1]-RC[-2]"
        w.Range("L2:L" & rows.Count + 1).FormulaR1C1 = "=IF(RC[-6]>0,RC[-4]/RC[-6],"""")"
        w.Range("M2:M" & rows.Count + 1).FormulaR1C1 = "=IF(RC[-7]>0,RC[-4]/RC[-7],"""")"
        w.Range("L2:M" & rows.Count + 1).NumberFormat = "0.0%"
    End If
    WriteCollection "Issues", Array("Severity", "Target", "Code", "Detail"), logs
    Ws("Issues").Columns("D").ColumnWidth = 85
    WriteAgeMatrix
    WriteAnnualCheck
    Application.Calculate
End Sub

Private Sub WriteAgeMatrix()
    Dim w As Worksheet, headersV() As Variant, s As Object, k As Variant, mk As Variant, out() As Variant
    Dim r As Long, c As Long, n As Long
    Set w = OutputWs("AgeMatrix")
    n = UBound(monthKeys) + 1
    If n + 8 > 16384 Or series.Count > 1000000 Then Err.Raise vbObjectError + 731, , "AgeMatrix exceeds Excel capacity. Reduce scope."
    ReDim headersV(0 To n + 7)
    headersV(0) = "Country": headersV(1) = "Origin": headersV(2) = "Group": headersV(3) = "Brand"
    headersV(4) = "MLModel": headersV(5) = "Metric": headersV(6) = "Basis": headersV(7) = "RawFamilyKey"
    For c = 0 To n - 1: headersV(c + 8) = CLng(monthKeys(c)): Next c
    WriteHeader w, headersV
    ReDim out(1 To series.Count, 1 To n + 8)
    For Each k In SortedKeys(series)
        r = r + 1: Set s = series(k)
        out(r, 1) = s("Country"): out(r, 2) = s("Origin"): out(r, 3) = s("Group")
        out(r, 4) = s("Brand"): out(r, 5) = s("Model"): out(r, 6) = s("Metric")
        out(r, 7) = s("Basis"): out(r, 8) = s("RawKey")
        For c = 0 To n - 1: out(r, c + 9) = s("Ages")(CStr(monthKeys(c))): Next c
    Next k
    w.Cells(2, 1).Resize(series.Count, n + 8).Value2 = out
    w.Cells(1, 9).Resize(1, n).NumberFormat = "yyyy-mm"
    w.Cells(2, 9).Resize(series.Count, n).NumberFormat = "0"
    w.Columns("A:H").ColumnWidth = 22: w.Cells(1, 9).Resize(1, n).EntireColumn.ColumnWidth = 10
    w.Cells(1, 1).Resize(series.Count + 1, n + 8).AutoFilter
End Sub

Private Sub WriteAnnualCheck()
    Dim rows As Collection, k As Variant, a As Variant, fam As Object, spN As Variant, state As String
    Set rows = New Collection
    For Each k In SortedKeys(annualML)
        a = annualML(k): Set fam = families(CStr(a(0))): spN = Empty
        state = "SCOPE_NOT_CONFIRMED"
        If Yes(CfgV("SPAnnualComparable", "NO")) Then
            state = "INCOMPLETE_ML_YEAR"
            If CLng(a(1)) > CLng(CfgV("SPMaxActualYear", 2025)) Then
                state = "SP_YEAR_NOT_ACTUAL"
            ElseIf CBool(a(3)) And a(4).Count = 12 Then
                state = "SP_ANNUAL_MISSING"
                If fam("Years").Exists(CStr(a(1))) Then spN = fam("Years")(CStr(a(1))): state = "COMPARABLE_FULL_YEAR"
            End If
        End If
        rows.Add Array(a(0), a(1), a(2), a(4).Count, spN, Empty, state)
    Next k
    WriteCollection "SPAnnualCheck", Array("SPFamilyID", "Year", "MLKnownUnits", "ObservedMonths", "SPActualAnnualUnits", "Difference", "Status"), rows
    Dim w As Worksheet
    Set w = Ws("SPAnnualCheck"): w.Columns("A").ColumnWidth = 60
    If rows.Count > 0 Then w.Range("F2:F" & rows.Count + 1).FormulaR1C1 = "=IF(ISNUMBER(RC[-1]),RC[-3]-RC[-1],"""")"
End Sub

Public Sub ApplyApprovedReview()
    Dim a As Variant, r As Long, selected As Object, k As Variant, rowV As Variant, target As Worksheet
    Dim existing As Object, cr As Long, n As Long
    On Error GoTo Failed
    Initialise
    Set selected = D(): Set existing = D()
    a = Ws("Review").Range("A1").CurrentRegion.Value2
    For r = 2 To UBound(a, 1)
        If UCase$(Txt(a(r, 12))) = "APPROVE" Then
            k = Txt(a(r, 1))
            If selected.Exists(k) Then Err.Raise vbObjectError + 732, , "Approve only ONE candidate per RawFamilyKey: " & k
            selected.Add k, Array(a(r, 2), a(r, 3), a(r, 4), a(r, 6), "YES", "NO", "Reviewed candidate")
        End If
    Next r
    Set target = Ws("Crosswalk")
    For r = 2 To target.Cells(target.Rows.Count, 1).End(xlUp).Row
        k = RawKey(target.Cells(r, 1).Value2, target.Cells(r, 2).Value2, target.Cells(r, 3).Value2)
        If existing.Exists(k) Then Err.Raise vbObjectError + 733, , "Duplicate Crosswalk entries."
        existing.Add k, r
    Next r
    For Each k In selected.Keys
        rowV = selected(k)
        If existing.Exists(k) Then cr = CLng(existing(k)) Else cr = target.Cells(target.Rows.Count, 1).End(xlUp).Row + 1
        For n = 0 To 6: target.Cells(cr, n + 1).Value2 = rowV(n): Next n
    Next k
    MsgBox selected.Count & " approved mappings saved. Run RefreshASEAN next. Generation-fit approval remains NO.", vbInformation
    Exit Sub
Failed:
    MsgBox Err.Description, vbExclamation
End Sub

Public Sub BuildAgeChart()
    Dim w As Worksheet, a As Variant, b As Object, r As Long, k As Variant, v As Variant, c As Long
    Dim countryFilter As String, brandFilter As String, metricFilter As String, basisFilter As String
    Dim groupFilter As String, originFilter As String, ageFilter As String, co As ChartObject, out() As Variant
    On Error GoTo Failed
    Set w = Ws("Dashboard")
    countryFilter = UCase$(Txt(w.Range("B4").Value2))
    brandFilter = UCase$(Txt(w.Range("B5").Value2))
    metricFilter = UCase$(Txt(w.Range("B6").Value2))
    basisFilter = UCase$(Txt(w.Range("B7").Value2))
    groupFilter = UCase$(Txt(w.Range("B8").Value2))
    originFilter = UCase$(Txt(w.Range("B9").Value2))
    ageFilter = UCase$(Txt(w.Range("B10").Value2))
    If Len(countryFilter) = 0 Or Len(brandFilter) = 0 Or Len(metricFilter) = 0 Or Len(basisFilter) = 0 Or _
       Len(groupFilter) = 0 Or Len(originFilter) = 0 Or Len(ageFilter) = 0 Then Err.Raise vbObjectError + 734, , "Fill Dashboard B4:B10. Use ALL for brand/group/origin/age basis."
    If countryFilter = "ALL" Or metricFilter = "ALL" Or basisFilter = "ALL" Then _
        Err.Raise vbObjectError + 735, , "Select one country, metric and basis."
    Set b = D(): a = Ws("AgeSummary").Range("A1").CurrentRegion.Value2
    For r = 2 To UBound(a, 1)
        If UCase$(Txt(a(r, 1))) = countryFilter And UCase$(Txt(a(r, 5))) = metricFilter And UCase$(Txt(a(r, 6))) = basisFilter Then
            If (brandFilter = "ALL" Or UCase$(Txt(a(r, 4))) = brandFilter) And _
               (groupFilter = "ALL" Or UCase$(Txt(a(r, 3))) = groupFilter) And _
               (originFilter = "ALL" Or UCase$(Txt(a(r, 2))) = originFilter) And _
               (ageFilter = "ALL" Or UCase$(Txt(a(r, 19))) = ageFilter) Then
                k = CStr(a(r, 7))
                If Not b.Exists(k) Then b.Add k, Array(a(r, 7), 0#, 0#, 0#, 0#, 0#, 0#, 0#, 0#)
                v = b(k)
                For c = 1 To 8: v(c) = CDbl(v(c)) + CDbl(a(r, c + 7)): Next c
                b(k) = v
            End If
        End If
    Next r
    If b.Count = 0 Then Err.Raise vbObjectError + 739, , "No AgeSummary rows match Dashboard selections."
    Dim lastData As Long
    lastData = w.Cells(w.Rows.Count, 1).End(xlUp).Row
    If lastData >= 13 Then w.Range("A13:L" & lastData).ClearContents
    w.Range("A13:I13").Value = Array("Month", "Y1", "Y2", "Y3", "Y4", "Y5", "Y6", "7PLUS", "UNKNOWN")
    ReDim out(1 To b.Count, 1 To 9): r = 0
    For Each k In SortedKeys(b)
        r = r + 1: v = b(k)
        For c = 0 To 8: out(r, c + 1) = v(c): Next c
    Next k
    w.Range("A14").Resize(b.Count, 9).Value2 = out
    w.Range("A14").Resize(b.Count, 1).NumberFormat = "yyyy-mm"
    w.Range("B14").Resize(b.Count, 8).NumberFormat = "#,##0"
    For Each co In w.ChartObjects: co.Delete: Next co
    Set co = w.ChartObjects.Add(w.Range("D2").Left, w.Range("D2").Top, 850, 340)
    co.Chart.ChartType = xlAreaStacked
    co.Chart.SetSourceData w.Range("A13:I" & b.Count + 13)
    co.Chart.PlotBy = xlColumns
    co.Chart.HasTitle = True: co.Chart.ChartTitle.Text = countryFilter & " " & metricFilter & " by model age (" & ageFilter & ")"
    co.Chart.Axes(xlCategory).TickLabels.NumberFormat = "yyyy-mm"
    co.Chart.Axes(xlValue).TickLabels.NumberFormat = "#,##0"
    w.Range("A11").Value = "Chart refreshed"
    w.Range("B11").Value = Format(Now, "yyyy-mm-dd hh:mm")
    Exit Sub
Failed:
    MsgBox Err.Description, vbExclamation
End Sub

Public Sub SelfTest_ASEAN()
    On Error GoTo Failed
    AssertTrue MonthSerial("2024-02") = CLng(DateSerial(2024, 2, 1)), "ISO month"
    AssertTrue MonthSerial(202402) = CLng(DateSerial(2024, 2, 1)), "YYYYMM month"
    AssertTrue MonthSerial("202413") = 0, "invalid month"
    AssertTrue Age0(CLng(DateSerial(2025, 1, 1)), CLng(DateSerial(2024, 1, 1))) = 12, "age boundary"
    AssertTrue Band(0) = "Y1" And Band(11) = "Y1", "year 1"
    AssertTrue Band(12) = "Y2" And Band(71) = "Y6" And Band(72) = "7PLUS", "year boundaries"
    AssertTrue Norm("A-TTO 3") = Norm("Atto3"), "safe normalization"
    AssertTrue Norm("Model Plus") <> Norm("Model"), "variant preserved"
    AssertTrue Similarity("A3", "A5") = 0, "digits protected"
    AssertTrue Similarity("ALPHA", "ALPHS") > 0.79, "edit distance"
    AssertTrue CLng(DateAdd("m", -12, DateSerial(2025, 1, 1))) = CLng(DateSerial(2024, 1, 1)), "zero-based inverse"
    AssertTrue CLng(DateAdd("m", -(13 - 1), DateSerial(2025, 1, 1))) = CLng(DateSerial(2024, 1, 1)), "one-based inverse"
    MsgBox "SelfTest_ASEAN passed (12 assertions).", vbInformation
    Exit Sub
Failed:
    MsgBox "Self-test failed: " & Err.Description, vbCritical
End Sub

Private Sub AssertTrue(ByVal condition As Boolean, ByVal name As String)
    If Not condition Then Err.Raise vbObjectError + 736, , name
End Sub
